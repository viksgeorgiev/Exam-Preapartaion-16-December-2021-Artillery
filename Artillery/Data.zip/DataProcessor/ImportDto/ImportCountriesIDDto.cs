﻿namespace Artillery.DataProcessor.ImportDto
{
    public class ImportCountriesIDDto
    {
        public int Id { get; set; }
    }
}